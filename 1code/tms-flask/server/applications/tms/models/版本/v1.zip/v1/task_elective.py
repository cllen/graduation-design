from sqlalchemy import Column, String, Integer, Boolean
from applications import db

class TaskElective(db.Model):
	__tablename__ = 'task_elective'

	id = Column(Integer, primary_key=True)

	# 学号
	account = Column(String(2000))
	# 课序号
	course_numbering = Column(String(2000))
	# 是否代选
	is_agent_selected = Column(String(2000))
	# 选课审核状态
	auditive_status = Column(String(2000))
	# 选课时间
	selected_date = Column(String(2000))
	# 审核日期
	audited = Column(String(2000))
	# 审核人
	audited_account = Column(String(2000))
