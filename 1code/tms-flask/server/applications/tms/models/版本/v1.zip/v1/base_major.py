from sqlalchemy import Column, String, Integer, Boolean
from applications import db

class BaseMajor(db.Model):
	__tablename__ = 'base_major'

	id = Column(Integer, primary_key=True)

	# 专业编号
	number = Column(String(256))
	# 专业代码
	code = Column(String(256))
	# 专业名称
	name = Column(String(256))
	# 专业英文名称
	english_name = Column(String(256))
	# 学制
	education_system = Column(String(256))
	# 专业方向名称
	zyfxmc = Column(String(256))
	# 专业简称
	short_name = Column(String(256))
	# 建立年月
	found_date = Column(String(256))
	# 专业教师数
	teacher_number = Column(String(256))
	# 开设机构号
	insitution_number = Column(String(256))
	# 总学分
	total_credict = Column(String(256))
