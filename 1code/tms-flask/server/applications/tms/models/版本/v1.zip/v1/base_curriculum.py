from sqlalchemy import Column, String, Integer, Boolean
from applications import db

class BaseCurriculum(db.Model):
	__tablename__ = 'base_curriculum'

	# 课程号
	id = Column(Integer, primary_key=True)
	# # 课程号
	# kch = Column(String(256))
	
	# 课程名称
	name = Column(String(256))
	# 课程英文名
	english_name = Column(String(256))
	# 课程别名
	other_name = Column(String(256))
	# 课程介绍
	introduce = Column(String(256))
	# 学分
	credit = Column(String(256))
	# 总学时
	total_class_hour = Column(String(256))
	# 理论学时
	theory_class_hour = Column(String(256))
	# 实践学时
	practice_class_hour = Column(String(256))
	# 其他学时
	other_class_hour = Column(String(256))
	# 参考书目
	textbook = Column(String(256))
	# 开课单位
	holder = Column(String(256))
	# 考试形式
	examination_form = Column(String(256))
	# 授课方式码
	teaching_form = Column(String(256))
	# 课程费用
	cost = Column(String(256))