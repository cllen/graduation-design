from sqlalchemy import Column, String, Integer, Boolean
from applications import db

class PlanCourseScheduling(db.Model):
	__tablename__ = 'plan_course_scheduling'

	id = Column(Integer, primary_key=True)

	"""
		某个老师的课程
	"""
	
	# 课序号
	plan_course_id = Column(String(2000))
	# 开课单位
	insitution_name = Column(String(2000))
	# 学期名称
	year_name = Column(String(2000))
	# 上课时间
	datetime = Column(String(2000))
	# 中文简称
	short_name = Column(String(2000))
	# 教学地点
	teaching_place = Column(String(2000))
	# 教学资源
	teaching_resource = Column(String(2000))
	# 计划人数
	expected_members = Column(String(2000))
	# 已选人数
	actual_members = Column(String(2000))
	# 教学班所在校区
	campus = Column(String(2000))
	# 选课年级
	grade = Column(String(2000))
	# 起始周
	start_week = Column(String(2000))
	# 终止周
	end_week = Column(String(2000))
	# 教师教工号
	teacher_account = Column(String(2000))
	# 教师姓名
	teacher_name = Column(String(2000))
	# 周学时
	hours_of_week = Column(String(2000))
	# 上课行政班代码
	class_administrative_code = Column(String(2000))
	# 教学班名称
	class_name = Column(String(2000))
	# 开课说明（备注）
	remark = Column(String(2000))