from sqlalchemy import Column, String, Integer, Boolean
from applications import db

class GradeClass(db.Model):
	__tablename__ = 'grade_class'

	id = Column(Integer, primary_key=True)

	
	# 行政班代码
	administrative_code = Column(String(2000))
	# 年级代码
	grade_code = Column(String(2000))
	# 行政班名称
	administrative_name = Column(String(2000))
	# 专业代码
	specialty_code = Column(String(2000))
	# 建班年月
	found_date = Column(String(2000))
	# 班主任工号
	headteacher_id = Column(String(2000))
	# 教室编号
	classroom_numbering = Column(String(2000))
	# 男生人数
	male_number = Column(String(2000))
	# 女生人数
	female_number = Column(String(2000))
	# 总人数
	total_number = Column(String(2000))
	# 班长学号
	class_monitor_id = Column(String(2000))
	# 机构号
	insitution_id = Column(String(2000))
	# 校区代码
	campus_code = Column(String(2000))
