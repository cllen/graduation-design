from sqlalchemy import Column, String, Integer, Boolean
from applications import db

class GradeGrade(db.Model):
	__tablename__ = 'grade_grade'

	id = Column(Integer, primary_key=True)

	
	# 年级代码（根据年份编号）
	code = Column(String(2000))
	# 年级名称
	name = Column(String(2000))
	# 所属年份
	year = Column(String(2000))
	# 年级状态
	sate = Column(String(2000))