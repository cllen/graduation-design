from sqlalchemy import Column, String, Integer, Boolean
from applications import db

class Major(db.Model):
	__tablename__ = 'major'

	id = Column(Integer, primary_key=True)

	# 
	# 
	# 
	# 
	# 
	# 
	# 
	# 
	# 
	# 
	# 
	# 
	# 
	# 
	# 
	# 
	# 
	# 
	# 
	# 
	# 
	# 
	# 
	# 
	# 
	# 
	# 
	# 
	# 
	# 
	# 